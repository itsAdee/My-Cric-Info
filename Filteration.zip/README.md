# Database-Semester-Project
Here we collaborate to make a cricket management system to best of our abilities
