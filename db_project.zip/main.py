from flask import Flask, render_template, request, redirect, url_for;

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('nav.html')

@app.route('/home')
def Home_page():
    return render_template('Home_page.html')

@app.route('/stats')
def stats():
    return render_template('stats.html')


@app.route('/sample')
def sample():
    return render_template('sample.html')
    


if __name__ == '__main__':
    app.run(debug=True)
